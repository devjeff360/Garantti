<?php session_start();
error_reporting(0);

include_once("config.php");

  $email = $_SESSION["email"];
   if(!isset($_SESSION['email'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
 $getdata = $con->query("SELECT * FROM profile WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $user = $gd['user']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $city = $gd['city']; 
                    $zip = $gd['zip']; 
                    $language = $gd['language']; 
                    $accno = $gd['accno']; 
                    $image = $gd['image']; 
                    $status = $gd['status']; 
        }
    

    
}


?>
<!DOCTYPE html>


<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets2-path="assets2/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Gűaranttibbva | Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png">
 

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets2/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets2/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets2/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets2/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets2/vendor/js/helpers.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets2/js/config.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu">
          <div class="app-brand demo">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
              <img src="blogo.png" style="width:150px; height:auto; display:inline"/>
                <b class='' style='font-size:19px; display:inline'></b></span></a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item">
              <a href="index.php" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>
            <li class="menu-item">
              <a href="portifolios.php" class="menu-link ">
                <i class="menu-icon tf-icons bx bxs-bank"></i>
                <div data-i18n="Analytics">Savings</div>
              </a>
            </li>
           
            
            <li class="menu-item">
              <a href="fund.php" class="menu-link ">
              <i class='menu-icon tf-icons bx bx-money'></i>
                <div data-i18n="Analytics">Deposit</div>
              </a>
            </li>
            
            
            <!----------------------------------------------------------------->
            
            
            
            
            <li class="menu-item ">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-wallet"></i>
                <div data-i18n="Layouts">Transfer</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="savings-transfer-type.php" class="menu-link">
                    <div data-i18n="Without menu">From Savings</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="transfer-type.php" class="menu-link">
                    <div data-i18n="Without navbar">From Credit</div>
                  </a>
                </li> 
              </ul>
            </li>

            
            
            
            
            <!----------------------------------------------------------------->
            

            <!-- Layouts -->
            <li class="menu-item active open">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Layouts">Transactions</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="deposits.php" class="menu-link">
                    <div data-i18n="Without menu">Deposits</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="withdrawals.php" class="menu-link">
                    <div data-i18n="Without navbar">Withdrawals</div>
                  </a>
                </li> 
              </ul>
            </li>

            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Pages</span>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div data-i18n="Account Settings">Account Settings</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="profile.php" class="menu-link">
                    <div data-i18n="Account">Profile</div>
                  </a>
                </li>
              </ul>
            </li>
             <li class="menu-item">
              <a href="mailto:support@Centennialbank.com" class="menu-link">
              <i class='bx bx-headphone menu-icon tf-icons'></i>
                <div data-i18n="Analytics">Support</div>
              </a>
            </li>
            <li class="menu-item">
              <a href="../Login/index.php" class="menu-link">
              <i class='bx bx-lock menu-icon tf-icons'></i>
                <div data-i18n="Analytics">Logout</div>
              </a>
            </li>
            <br><br><br>
          </ul>
        </aside>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          
          <style>
           .layout-menu{
            background-color: #fff !important;
            color:black !important;
           }
            .modal-content{
              background-color: #273272;
              color: white;
            }
            .modal-header h3{
              color: white !important;
            }
            .btn-primary{
              background: #273272 !important;

            }
            .btn-outline-primary{
              border-color:#273272 !important;
              color: #273272 !important;
            }
            .text-primary{
              color:#273272 !important;
            }
            .btn-outline-primary:hover{
              border-color:#273272 !important;
              background-color: #273272 !important;
              color:white !important;
            }
            .layout-wrapper{
              background-color: #e3e6f5;
            }
            .btn{
              box-shadow: none !important;
            }
            a {
              color: #273272 !important;
          }
          .layout-navbar{
              height: 5rem !important;
          }
          .brand-bg{
              background: #17358B;
          }
          html,body{
              overflow-x:hidden;
          }
          </style>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div id="top-box" class="container-fluid flex-grow-1 container-p-y light-bg py-2">
                <!-- Layout Demo -->
              
            <!-- / Content -->
             <div class="app-brand demo justify-content-center pb-4">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
              <img src="blogo.png" style="width:150px; height:auto; display:inline"/>
                <b class='' style='font-size:21px; display:inline'></b></span></a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
            </div>


<!-- Transactions -->
<div class="row">
<div class="col-md-12 col-lg-12 order-2 mb-4 mx-auto">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="card-title m-0 me-2">Withdrawals</h5>
                      <div class="dropdown">
                       
                       
                      </div>
                    </div>
                    <div class="card-body">
                    <div class="table-responsive text-nowrap">
                 <table class="table">
                    <thead>
                      <tr>
                        <th>Transaction id</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                       <?php
                        
                        $gettrans = $con->query("SELECT * FROM transaction WHERE email = '$email' AND type = 'Withdrawal' ORDER BY id DESC LIMIT 10") or die(mysqli_error($con));
                      
                            while($gtt = $gettrans->fetch_assoc()){
                                $tid = $gtt['tid'];
                                $amt = $gtt['amt'];
                                $type = $gtt['type'];
                                $tdate = $gtt['tdate'];
                                $status = $gtt['status'];
                            
                      ?>
                    <tbody class="table-border-bottom-0">
                        <tr>
                            <td><?php echo $tid ?></td>
                            <td><?php echo $amt ?></td>
                            <td><?php echo $status ?></td>
                            <td><?php echo $tdate ?></td>
                        </tr>
                        <?php } ?>
                                          
                    </tbody>
                  </table>
                </div>
                    </div>
                  </div>
                </div>
                <!--/ Transactions -->
                        </div>



<footer class="content-footer footer light-bg">
              <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                 Gűaranttibbva
                  
                </div>
                <div>
                  

                  <a
                    href="mailto:support@Centennialbank.com"
                    target="_blank"
                    class="footer-link me-4"
                    >Support</a
                  >
                </div>
              </div>
            </footer>
            
            <div class="row">
            <div class="col-8 mx-auto">
            <nav class="fixed fixed-bottom card shadow-sm" style="z-index:5000;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <a href="index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-home-alt"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <button class="btn layout-menu-toggle" style="color:#17358B">
                                <i class="bx bx-menu"></i>
                            </button>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="profile.php">
                           <button class="btn" style="color:#17358B">
                                <i class="bx bx-user"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="../Login/index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-power-off"></i>
                            </button>
                            </a>

                        </div>
                    </div>
                </div>
            </nav>
            </div>
            </div>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    

    <!-- Core JS -->
    <!-- build:js assets2/vendor/js/core.js -->
    <script src="assets2/vendor/libs/jquery/jquery.js"></script>
    <script src="assets2/vendor/libs/popper/popper.js"></script>
    <script src="assets2/vendor/js/bootstrap.js"></script>
    <script src="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets2/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets2/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
