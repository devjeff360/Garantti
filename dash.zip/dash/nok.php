<?php session_start();
error_reporting(0);

include_once("config.php");

  $email = $_SESSION["email"];
   if(!isset($_SESSION['email'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
 $getdata = $con->query("SELECT * FROM profile WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $user = $gd['user']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $city = $gd['city']; 
                    $zip = $gd['zip']; 
                    $language = $gd['language']; 
                    $accno = $gd['accno']; 
                    $image = $gd['image']; 
                    $status = $gd['status']; 
                    $nok = $gd['nok']; 
                    $rnok = $gd['rnok']; 
                    $nokphone = $gd['nokphone']; 
        }
    
}


?>
<!DOCTYPE html>


<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets2-path="assets2/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Gűaranttibbva | Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png">
 

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets2/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets2/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets2/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets2/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets2/vendor/js/helpers.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets2/js/config.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <?php
          
          include_once("aside.php");
          
        ?>
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          
          <style>
           .layout-menu{
            background-color: #fff !important;
            color:black !important;
           }
            .modal-content{
              background-color: #273272;
              color: white;
            }
            .modal-header h3{
              color: white !important;
            }
            .btn-primary{
              background: #273272 !important;

            }
            .btn-outline-primary{
              border-color:#273272 !important;
              color: #273272 !important;
            }
            .text-primary{
              color:#273272 !important;
            }
            .btn-outline-primary:hover{
              border-color:#273272 !important;
              background-color: #273272 !important;
              color:white !important;
            }
            .layout-wrapper{
              background-color: #e3e6f5;
            }
            .btn{
              box-shadow: none !important;
            }
            a {
              color: #273272 !important;
          }
          .layout-navbar{
              height: 5rem !important;
          }
          .brand-bg{
              background: #17358B;
          }
          html,body{
              overflow-x:hidden;
          }
          </style>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div id="top-box" class="container-fluid flex-grow-1 container-p-y light-bg py-2">
                <!-- Layout Demo -->
              
            <!-- / Content -->
             <div class="app-brand demo justify-content-center pb-4">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
              <img src="blogo.png" style="width:150px; height:auto; display:inline"/>
                <b class='' style='font-size:21px; display:inline'></b></span></a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
            </div>
<style>
  .form-control, .form-select{
    background-color: transparent;
  }
  
</style>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account Settings /</span> Account</h4>

              <div class="row">
                <div class="col-md-12">
                  
                  <div class="card mb-4">
                    <h3 class="card-header">Next of Kin Details</h3>
                    <!-- Account -->
                    <div class="card-body">
                      
                    </div>
                    <hr class="my-0" />
                    <div class="card-body">
                      <form action="#" method="POST" onsubmit="return true" enctype="multipart/form-data">
                  
                        <div class="row">
                          <div class="mb-3 col-md-6">
                            <label for="firstName" class="form-label">Full Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="fullname"
                              name="nok"
                              readonly
                              value="<?php echo $nok; ?>"                             
                            />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="lastName" class="form-label">Phone number</label>
                            <input class="form-control" type="text" name="nokphone" id="lastName" readonly value='<?php echo $nokphone; ?>' />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">Relationship</label>
                            <input
                              class="form-control"
                              type="text"
                              id="email"
                              name="rnok"
                              value="<?php echo $rnok; ?>"
                              readonly
                            />
                          </div>
                         
                         
                        </div>
                       </form>
                    </div>
                      
                      
                      
                    <!-- /Account -->
                  </div>
                    </div>
              </div>
            </div>
            <!-- / Content -->
<script>
    function copyRef() {
  /* Get the text field */
  var copyText = document.getElementById("ref");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

   /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);

  /* Alert the copied text */
  swal("Copied","Referral link copied to clipboard","success");
}

</script>

            


<footer class="content-footer footer light-bg">
              <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                 Gűaranttibbva
                  
                </div>
                <div>
                  

                  <a
                    href="mailto:support@Centennialbank.com"
                    target="_blank"
                    class="footer-link me-4"
                    >Support</a
                  >
                </div>
              </div>
            </footer>
            
            <div class="row">
            <div class="col-8 mx-auto">
            <nav class="fixed fixed-bottom card shadow-sm" style="z-index:5000;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <a href="index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-home-alt"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <button class="btn layout-menu-toggle" style="color:#17358B">
                                <i class="bx bx-menu"></i>
                            </button>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="profile.php">
                           <button class="btn" style="color:#17358B">
                                <i class="bx bx-user"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="../Login/index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-power-off"></i>
                            </button>
                            </a>

                        </div>
                    </div>
                </div>
            </nav>
            </div>
            </div>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    

    <!-- Core JS -->
    <!-- build:js assets2/vendor/js/core.js -->
    <script src="assets2/vendor/libs/jquery/jquery.js"></script>
    <script src="assets2/vendor/libs/popper/popper.js"></script>
    <script src="assets2/vendor/js/bootstrap.js"></script>
    <script src="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets2/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets2/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
