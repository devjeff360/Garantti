<?php session_start();
error_reporting(0);

include_once("config.php");

  $email = $_SESSION["email"];
   if(!isset($_SESSION['email'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
 $getdata = $con->query("SELECT * FROM profile WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $user = $gd['user']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $city = $gd['city']; 
                    $zip = $gd['zip']; 
                    $language = $gd['language']; 
                    $accno = $gd['accno']; 
                    $image = $gd['image']; 
                    $status = $gd['status']; 
        }
    
    //balance 
    
    $getbal = $con->query("SELECT * FROM bal WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gb = $getbal->fetch_assoc()){
            $s_bal = $gb['s_bal'];
            $c_bal = $gb['c_bal'];
        }
    
}


?>
<!DOCTYPE html>


<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets2-path="assets2/"
  data-template="vertical-menu-template-free"
>
    
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Gűaranttibbva | Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="https://Centennialbank.com/wp-content/uploads/2022/10/cropped-1-removebg-preview.png">
 

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets2/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets2/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets2/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets2/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets2/vendor/js/helpers.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets2/js/config.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
      
      <script src="//code.jivosite.com/widget/iJWYfakgcp" async></script>

  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        
          
        <?php
          
          include_once("aside.php");
          
        ?>

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          
          <style>
           .layout-menu{
            background-color: #fff !important;
            color:black !important;
           }
            .modal-content{
              background-color: #273272;
              color: white;
            }
            .modal-header h3{
              color: white !important;
            }
            .btn-primary{
              background: #273272 !important;

            }
            .btn-outline-primary{
              border-color:#273272 !important;
              color: #273272 !important;
            }
            .text-primary{
              color:#273272 !important;
            }
            .btn-outline-primary:hover{
              border-color:#273272 !important;
              background-color: #273272 !important;
              color:white !important;
            }
            .layout-wrapper{
              background-color: #e3e6f5;
            }
            .btn{
              box-shadow: none !important;
            }
            a {
              color: #273272 !important;
          }
          .layout-navbar{
              height: 5rem !important;
          }
          .brand-bg{
              background: #17358B;
          }
          html,body{
              overflow-x:hidden;
          }
          </style>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div id="top-box" class="container-fluid flex-grow-1 container-p-y light-bg py-2">
                <!-- Layout Demo -->
              
            <!-- / Content -->
             <div class="app-brand demo justify-content-center pb-4">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
              <img src="blogo.png" style="width:150px; height:auto; display:inline"/>
                <b class='' style='font-size:21px; display:inline'></b></span></a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
            </div>

 <style>
     .big-text{
         font-size:23px;
     }
 </style>
 <style>
 // --- base -------------------------------------------------------------------

 

// --- links ------------------------------------------------------------------

 

// --- header -----------------------------------------------------------------

.header {
  text-align: center;
  width: 600px;
  margin: 0 auto;
  padding: 50px 0;
  font-weight: 200;
}
  .card__title {
    font-size: 50px;
     
  }

   .card__subtitle {
    font-size: 20px;
    padding-bottom: 20px;
  }

   .card__body {
    min-height: 32px;
  }


// --- footer -----------------------------------------------------------------

.footer {
  margin: 0 auto;
  width: 600px;
  text-align: center;
  padding: 0 0 30px 0;
  font-size: 12px;
}

// --- panel ------------------------------------------------------------------

.panel {
  width: 600px;
  margin: 0 auto;
  margin-bottom: 50px;
  text-align: center;
}

// --- CARD: font -------------------------------------------------------------

@font-face {
  font-family: 'OCRA';
  src: url('fonts/OCRA.otf');
  src: url('fonts/OCRA.otf?#iefix') format('embedded-opentype'),
  url('fonts/OCRA.ttf') format('truetype')
}

// --- CARD -------------------------------------------------------------------

.card {
  font: 16px/1.5 'Helvetica Neue', Helvetica, sans-serif;
  position: relative;
  display: inline-block;
  vertical-align: middle;
  width: 425px;
  height: 270px;
  text-align: left;
  padding: 30px;
  margin-bottom: 50px;
   
  border-radius: 20px;
  box-sizing: border-box;
  
}
  .card__title {
    font-size: 50px;
    
  }

   .card__subtitle {
    font-size: 20px;
    padding-bottom: 20px;
  }

   .card__body {
    min-height: 32px;
  }


// --- footer -----------------------------------------------------------------

.footer {
  margin: 0 auto;
  width: 600px;
  text-align: center;
  padding: 0 0 30px 0;
  font-size: 12px;
}


  .card__number {
    font-size: 30px;
    padding: 20px 0 15px;
    text-align: center;
  }

  .card__expiry-date {
    font-size: 14px;
    padding-bottom: 20px;
    text-align: left;
  }

  .card__owner {
    text-align: left;
  }

  .card__logo {
    position: absolute;
    right: 20px;
    bottom: 0px;
  }

  .card__strip {
     
    height: 50px;
    margin-bottom: 30px;
  }

  .card__signature {
    float: left;
    width: 65%;
    height: 40px;
    margin-left: 10px;
     
  }

  .card__ccv {
    float: left;
    margin-top: 5px;
    padding: 7px;
     
     
    line-height: 1;
  }

  .card--front {
    font-size: 16px;
    font-family: 'Source Code Pro';
    text-shadow: 0 1px 1px rgba(0, 0, 0, .6);
  }

  .card--back {
    padding-left: 0;
    padding-right: 0;
    text-align: left;
  }

</style>
 
 <div class="row mt-2">
     <div class="col col-lg-8 mx-auto">
         <div class="row">
         <div class="col-7">
             <h1 class="p-2 text-dark">Welcome<br/><?php echo ucwords("$user"); ?></h1>
             
         </div>
         <div class="col-3">
             <div class="row">
                 <div class="col-6">
             <a href="transactions.php" class="float-end">
             <button class="btn float-end">
             <i class="bx bx-bell"></i>
             </button>
             </a>
             </div>
             <div class="col-6">
                 <span class="float-start">
             <a href="profile.php"  class="float-start">
             <button class="btn">
             <img src="<?php if($image){ echo "pics/$image"; }else{ echo"users.png"; } ?>" class="rounded rounded-circle" style="width:30px; height:30px;"/>
             </button>
             </a>
             </span>
             </div>
             </div>
             
         </div>
          </div>
          
         <div class="card">
             <div class="card-header brand-bg">
                 <div class="row">
                     
                     
                     
                     <div class="col-8 text-white align-item-center ">
                         
                         <h4 class="py-2  text-white big-text">
                             <?php echo ucwords("$fname"); ?> </h4>
                             <span class="badge bg-label-info"><?php echo $status; ?></span><br/>
                             <small class="text-light" class="big-text">ACCOUNT NUMBER</small>
                             <h5 class="py-2  text-white big-text"><?php echo $accno; ?></h5>
                             
                        
                     </div>
                     
                    
                 </div>
             </div>
             
            
             <div class="card-body border-top-1">
                 <div class="row py-2">
                     <div class="col-9">
                         <p class="">
                             <small>SAVINGS ACCOUNT</small>
                         </p>
                         <h1 class="mb-1">
                            $ <?php echo number_format("$s_bal",2); ?> USD
                         </h1>
                         <span class="mt-0">AVAILABLE BALANCE</span>
                     </div>
                     
                     <div class="col-3">
                         <a href="transactions.php">
                         <button class='btn border rounded-circle'>
                             <i class='bx bx-dock-top'style="color:#17358B"></i>
                         </button>
                         </a>
                        
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 
 <div class="row">
     <div class="col-lg-8 mx-auto my-2">

  
  <div class="card">
      <div class="card-body border-top-1">
                 <div class="row py-2">
                     <div class="col-9">
                         <p class="">
                             <small>CHECKINGS ACCOUNT</small>
                         </p>
                         <h1 class="mb-1">
                            $ <?php echo number_format("$c_bal",2); ?> USD
                         </h1>
                         <span class="mt-0">AVAILABLE BALANCE</span>
                     </div>
                     
                     <div class="col-3">
                         <a href="transactions.php">
                         <button class='btn border rounded-circle'>
                             <i class='bx bx-bell'style="color:#17358B"></i>
                         </button>
                         </a>
                        
                     </div>
                 </div>
             </div>
  </div>
  
</div>
</div>
 
 
 <!-- Transactions -->
                <div class="col-md-12 col-lg-8 mb-4 mx-auto my-4">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="card-title m-0 me-2">Recent Transaction History</h5>
                      <div class="dropdown">
                       
                       
                      </div>
                    </div>
                    
                    
                    <div class="card-body">
                    <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead class="text-dark">
                      <tr>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                      <?php
                        
                        $gettrans = $con->query("SELECT * FROM transaction WHERE email = '$email' ORDER BY id DESC LIMIT 10") or die(mysqli_error($con));
                      
                            while($gtt = $gettrans->fetch_assoc()){
                                $tid = $gtt['tid'];
                                $amt = $gtt['amt'];
                                $type = $gtt['type'];
                                $tdate = $gtt['tdate'];
                                $status = $gtt['status'];
                            
                      ?>
                    <tbody class="table-border-bottom-0 text-dark">
                        <tr>
                            <td><?php echo $amt ?></td>
                            <td><?php echo $type ?></td>
                            <td><?php echo $status ?></td>
                            <td><?php echo $tdate ?></td>
                        </tr>
                        <?php } ?>
                                          
                    </tbody>
                  </table>
                </div>
                    </div>
                  </div>
                </div>
                </div>
                <!--/ Transactions -->
 
 
 <footer class="content-footer footer light-bg">
              <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                 Gűaranttibbva
                  
                </div>
                <div>
                  

                  <a
                    href="mailto:support@Centennialbank.com"
                    target="_blank"
                    class="footer-link me-4"
                    >Support</a
                  >
                </div>
              </div>
            </footer>
            
            <div class="row">
            <div class="col-8 mx-auto">
            <nav class="fixed fixed-bottom card shadow-sm" style="z-index:5000;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <a href="index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-home-alt"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <button class="btn layout-menu-toggle" style="color:#17358B">
                                <i class="bx bx-menu"></i>
                            </button>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="profile.php">
                           <button class="btn" style="color:#17358B">
                                <i class="bx bx-user"></i>
                            </button>
                            </a>
                        </div>
                        <div class="col-3" style="color:#17358B">
                            <a href="../Login/index.php">
                            <button class="btn" style="color:#17358B">
                                <i class="bx bx-power-off"></i>
                            </button>
                            </a>

                        </div>
                    </div>
                </div>
            </nav>
            </div>
            </div>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    

    <!-- Core JS -->
    <!-- build:js assets2/vendor/js/core.js -->
    <script src="assets2/vendor/libs/jquery/jquery.js"></script>
    <script src="assets2/vendor/libs/popper/popper.js"></script>
    <script src="assets2/vendor/js/bootstrap.js"></script>
    <script src="assets2/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets2/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets2/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
