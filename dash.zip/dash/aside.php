<!-- Menu -->
        <aside id="layout-menu" class="layout-menu menu-vertical menu">
          <div class="app-brand demo">
            <a href="index.php" class="app-brand-link">
              <span class="app-brand-logo demo">
              <img src="blogo.png" style="width:150px; height:auto; display:inline"/>
                <b class='' style='font-size:19px; display:inline'></b></span></a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item">
              <a href="index.php" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>
            <!--<li class="menu-item">
              <a href="portifolios.php" class="menu-link ">
                <i class="menu-icon tf-icons bx bxs-bank"></i>
                <div data-i18n="Analytics">Savings</div>
              </a>
            </li>-->
           
            
            <li class="menu-item">
              <a href="fund.php" class="menu-link ">
              <i class='menu-icon tf-icons bx bx-money'></i>
                <div data-i18n="Analytics">Deposit</div>
              </a>
            </li>
            
           <li class="menu-item">
              <a href="savings-transfer-type.php" class="menu-link ">
              <i class='menu-icon tf-icons bx bx-wallet'></i>
                <div data-i18n="Analytics">Transfer</div>
              </a>
            </li>
            <!-----------------------------------------------------------------
            
            
            
            
            <li class="menu-item ">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-wallet"></i>
                <div data-i18n="Layouts">Transfer</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="savings-transfer-type.php" class="menu-link">
                    <div data-i18n="Without menu">From Savings</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="transfer-type.php" class="menu-link">
                    <div data-i18n="Without navbar">From Credit</div>
                  </a>
                </li> 
              </ul>
            </li>

            
            
            
            
            ----------------------------------------------------------------->
            

            <!-- Layouts -->
            <li class="menu-item active open">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Layouts">Transactions</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="deposits.php" class="menu-link">
                    <div data-i18n="Without menu">Deposits</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="withdrawals.php" class="menu-link">
                    <div data-i18n="Without navbar">Withdrawals</div>
                  </a>
                </li> 
              </ul>
            </li>

            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Pages</span>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle ">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div data-i18n="Account Settings">Account Settings</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="profile.php" class="menu-link">
                    <div data-i18n="Account">Profile</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="nok.php" class="menu-link">
                    <div data-i18n="Account">Next of Kin</div>
                  </a>
                </li>
              </ul>
            </li>
             <li class="menu-item">
              <a href="mailto:info@firstguaranti.com" class="menu-link">
              <i class='bx bx-headphone menu-icon tf-icons'></i>
                <div data-i18n="Analytics">Support</div>
              </a>
            </li>
            <li class="menu-item">
              <a href="../Login/index.php" class="menu-link">
              <i class='bx bx-lock menu-icon tf-icons'></i>
                <div data-i18n="Analytics">Logout</div>
              </a>
            </li>
            <br><br><br>
          </ul>
        </aside>
        <!-- / Menu -->