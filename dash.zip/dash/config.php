<?php

    $con = new mysqli('localhost','root','','centi') or die("CANNOT CONECT");


?>