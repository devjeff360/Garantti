<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
    $aid = $_GET['aid'];
    $did = $_GET['did'];
    $disid = $_GET['disid'];
    
    if($aid){
           $activate = $con->query("UPDATE profile SET status = 'ACTIVE' WHERE id = '$aid'") or die(mysqli_error($con));
    
      
        if($activate == TRUE){
            echo"<script>alert('ACCOUNT ACTIVATED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }else{
            echo"<script>alert('FAILED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }
    }else if($did){
        $activate = $con->query("UPDATE profile SET status = 'DORMANT' WHERE id = '$did'") or die(mysqli_error($con));
    
      
        if($activate == TRUE){
            echo"<script>alert('ACCOUNT DEACTIVATED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }else{
            echo"<script>alert('FAILED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }
    }else if($disid){
        $activate = $con->query("UPDATE profile SET status = 'DISABLED' WHERE id = '$did'") or die(mysqli_error($con));
    
      
        if($activate == TRUE){
            echo"<script>alert('ACCOUNT DEACTIVATED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }else{
            echo"<script>alert('FAILED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }
    }
     
}

  ?>