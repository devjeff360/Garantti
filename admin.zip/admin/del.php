<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
    $email = $_GET['id'];
    
    $delete1 = $con->query("DELETE FROM profile WHERE email = '$email'") or die(mysqli_error($con));
    $delete2 = $con->query("DELETE FROM bal WHERE email = '$email'") or die(mysqli_error($con));
    
      
        if($delete1 && $delete2 == TRUE){
            echo"<script>alert('ACCOUNT DELETED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }else{
            echo"<script>alert('FAILED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allaccts.php' />";
        }
   
}

  ?>