
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-usertitle">
				<div class="profile-usertitle-name">Administrator</div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<li class="active"><a href="index.php"><em class="fa fa-tachometer-alt">&nbsp;</em> Dashboard</a></li>
			<li><a href="allaccts.php"><em class="fa fa-user">&nbsp;</em> All Accounts</a></li>
			<li><a href="allbal.php"><em class="fa fa-bank">&nbsp;</em> Accounts Balance</a></li>
			<li><a href="trans.php"><em class="fa fa-toggle-off">&nbsp;</em> Transactions</a></li>
			<li><a href="../Login/adminlogin.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->