<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
    $id = $_GET['id'];
    
    $delete1 = $con->query("UPDATE admin SET status = '$id'") or die(mysqli_error($con));
    
      
        if($delete1 == TRUE){
            echo"<script>alert('SWITCHED $id');</script>";
            echo"<meta http-equiv='refresh' content='0 url=index.php' />";
        }else{
            echo"<script>alert('FAILED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=index.php' />";
        }
   
}

  ?>