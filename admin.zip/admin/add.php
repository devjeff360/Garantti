<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
    
      $getdata = $con->query("SELECT * FROM profile WHERE id = '".$_GET['id']."'") or die(mysqli_error($con));
               
                while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $email = $gd['email']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $user = $gd['user']; 
                    $pass = $gd['pass'];  
                    $accno = $gd['accno']; 

    }
    
    
    
        if(isset($_POST['register'])){
        $email = $_POST['email'];
        $amt = $_POST['amt'];
        $type = $_POST['type'];
        $tdate = $_POST['tdate'];
        $rand = rand(01234,56789);
        $tid = "05023$rand";
      
        
        $insert = $con->query("INSERT INTO transaction (email, tid, amt, type, tdate, status) VALUES ('$email','$tid','$amt','$type','$tdate','Successful')") or die(mysqli_error($con));
        
        
        if($insert == TRUE){
            echo"<script>alert('TRANSACTION CREATED');</script>";
            echo"<meta http-equiv='refresh' content='0 url=view.php?id=$email' />";
        }else{
            echo"<script>alert('FAILED');</script>";
        }
      
        
    }
    
}

  ?><!DOCTYPE html>
<html>
<head> <meta name="robots" content="noindex,nofollow"/>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin - Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/fontawesome-free/css/all.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"/>
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#">Admin Dashboard</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php
	include_once "sidebar.php";
	?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">TRANSACTION</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			
<br />
            <center><h3>Add New Transaction</h3></center>
            <?php
                $email = $_GET['id'];
            ?>
            
            <form action="#" method="post" enctype="multipart/form-data" style="width:90%; margin-left:5%;">
                  
                <div class="row">
                     <div class="col-md-6">
                    <label>Email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" readonly style="margin-left:10px;" />
                    </div>
                    
                    <div class="col-md-6">
                        <label>Amount (<i class="fa fa-usd"></i>)</label>
                        <input type="text" name="amt" class="form-control" value="" style="margin-left:10px;" />
                    </div>
                   
                </div>
                
                 <div class="row">
                    <div class="col-md-6">
                    <label>Transaction Type</label>
                      <select class="form-control" name="type" style="margin-left:10px; height:45px;">
                        <option value="">-- SELECT TYPE --</option>    
                        <option value="Deposit">Deposit</option>    
                        <option value="Withdrawal">Withdrawal</option>    
                    </select>
                    </div>
                     
                    <div class="col-md-6">
                       <label>Date</label>
                        <input type="date" name="tdate" class="form-control" value="" style="margin-left:10px;" />
                     </div>
                </div>
                
                 
                <br />
                <button class="btn btn-success" name="register" type="submit">Add Transaction</button>
            
            </form>
			
        <br />
        <br />
        <br />
        <br />
        </div>		
		
		
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>