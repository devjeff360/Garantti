<?php

$server = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "new_db";

$con = new mysqli($server, $dbUsername, $dbPassword, $dbName) or die("Connection Failed %s\n". $con -> error);