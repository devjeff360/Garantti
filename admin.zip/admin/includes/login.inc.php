<?php

include_once "dbh.inc.php";
session_start();

if(isset($_POST['login-btn'])){
    $email = mysqli_real_escape_string($con, $_POST['email']) ;
    $password = mysqli_real_escape_string($con, $_POST['pass']);

    $sql = "SELECT * FROM admins WHERE adminEmail = '$email' AND adminPassword = '$password'";

    $result = mysqli_query($con, $sql);
    
    $resultCheck = mysqli_num_rows($result);

    if($resultCheck > 0 && $row = mysqli_fetch_assoc($result)){
        header("Location: /New Admin/panelindex.php");
         $_SESSION['id'] = $row['adminId'];
        $_SESSION['email'] = $row['adminEmail'];
        $_SESSION['password'] = $row['adminPassword'];
    }else{
        header ("Location: /New Admin/index.php?Login=Error");
    }
}