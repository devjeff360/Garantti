<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
    
      $getdata = $con->query("SELECT * FROM profile WHERE id = '".$_GET['id']."'") or die(mysqli_error($con));
               
                while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $email = $gd['email']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $user = $gd['user']; 
                    $pass = $gd['pass']; 
                    $accno = $gd['accno']; 
                    $city = $gd['city']; 
                    $zip = $gd['zip']; 
                    $status = $gd['status']; 
                    $image = $gd['image']; 
                    $nok = $gd['nok']; 
                    $rnok = $gd['rnok']; 
                    $nokphone = $gd['nokphone']; 

    }
    
    if(isset($_POST['register'])){
        $fname = mysqli_real_escape_string($con, $_POST['fname']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);
        $address = mysqli_real_escape_string($con, $_POST['address']);
        $city = mysqli_real_escape_string($con, $_POST['city']);
        $zip = mysqli_real_escape_string($con, $_POST['zip']);
        $user = mysqli_real_escape_string($con, $_POST['user']);
        $pass = mysqli_real_escape_string($con, $_POST['pass']);
        $nok = mysqli_real_escape_string($con, $_POST['nok']);
        $rnok = mysqli_real_escape_string($con, $_POST['rnok']);
        $nokphone = mysqli_real_escape_string($con, $_POST['nokphone']);
        
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        
        $folder = "../dash/pics/";
            
            if($idf || $idb || $image){
                  
        move_uploaded_file($tmp, $folder.$image);
                
                 if($status == "NOT SETUP"){ $status = "PENDING"; }else{$status = $status; }
        
        $update = $con->query("UPDATE profile SET fname = '$fname', phone = '$phone', address = '$address', image = '$image', city = '$city', zip = '$zip', nok = '$nok', rnok = '$rnok', nokphone = '$nokphone', status = '$status' WHERE email = '$email'") or die(mysqli_error($con));
                
            }else{
                $update = $con->query("UPDATE profile SET fname = '$fname', phone = '$phone', address = '$address', city = '$city', zip = '$zip', nok = '$nok', rnok = '$rnok', nokphone = '$nokphone', status = '$status' WHERE email = '$email'") or die(mysqli_error($con));
            }
      
        
        if($update == TRUE){
            echo"<script>alert('UPDATED AND ACTIVATED');</script>";
             echo"<meta http-equiv='refresh' content='0 url=#' />";
        }else{
            echo"<script>alert('ACCOUNT UPDATE FAILED');</script>";
             echo"<meta http-equiv='refresh' content='0 url=#' />";
        }
      
        
    }
    
}

  ?><!DOCTYPE html>
<html>
<head> <meta name="robots" content="noindex,nofollow"/>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin - Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/fontawesome-free/css/all.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#">Admin Dashboard</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php
	include_once "sidebar.php";
	?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">UPDATE ACCOUNT</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			
<br />
            <center><h3>EDIT THIS ACCOUNT</h3></center>
             <?php
                
                    if($image){
                        echo"<div class='col-md-6'><img src='../dash/pics/$image' style='width:200px; height:200px;' /></div>";
                    }else{
                        echo" ";
                    }
                
                    
                ?>
         <form action="#" method="post" enctype="multipart/form-data" style="width:90%; margin-left:5%;">
                   <center><b><i>PERSONAL DATA</i></b></center>
                <div class="row">
                    <div class="col-md-6">
                        <label>Fullname</label>
                        <input type="text" name="fname" class="form-control" value="<?php echo $fname; ?>" style="margin-left:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" readonly style="margin-left:10px;" />
                    </div>
                </div>
                
                 <div class="row">
                    <div class="col-md-6">
                        <label>Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>" style="margin-left:10px;" />
                    </div>
                    <div class="col-md-6">
                        <label>City</label>
                        <input type="text" name="city" class="form-control" value="<?php echo $city; ?>" style="margin-left:10px;" />
                          </div>
                </div>
                  <div class="row">
                    <div class="col-md-6">
                        <label>Zip</label>
                        <input type="text" name="zip" class="form-control" value="<?php echo $zip; ?>" style="margin-left:10px;" />
                      </div>
                       <div class="col-md-6">
                        <label>Address</label>
                        <input type="text" name="address" class="form-control" value="<?php echo $address; ?>" style="margin-left:10px;" />
                    </div>
                      
                       <div class="col-md-12">
                    <label>Passport Photograph</label>
                        <input type="file" name="image" class="form-control" style="margin-left:10px;" />
                    </div>
                </div>
             
             <p><b><i>Next of Kin details</i></b></p>
              
               <div class="row">
                    <div class="col-md-6">
                        <label>Next of Kin Fullname</label>
                        <input type="text" name="nok" class="form-control" required value="<?php echo $nok; ?>" style="margin-left:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Phone number of Next of Kin</label>
                        <input type="text" name="nokphone" class="form-control" required value="<?php echo $nokphone; ?>" style="margin-left:10px;" />
                    </div>
                    <div class="col-md-12">
                    <label>Relationship with Next of Kin</label>
                        <select name="rnok" class="form-control" required style="margin-left:10px;">
                            <option value="<?php echo $rnok; ?>"><?php echo $rnok; ?></option>
                            <option value="Spouse">Spouse</option>
                            <option value="Sibbling">Sibbling</option>
                            <option value="Son">Son</option>
                            <option value="Daughter">Daughter</option>
                            <option value="Extended Relative">Extended Relative</option>
                        </select>
                    </div>
                </div>
              
              <p><b><i>Login details</i></b></p>
                
             
                 <div class="row">
                    <div class="col-md-6">
                        <label>Username</label>
                        <input type="text" name="user" class="form-control" value="<?php echo $user; ?>" style="margin-left:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Password</label>
                        <input type="password" name="pass" class="form-control" value="<?php echo $pass; ?>" style="margin-left:10px;" />
                    </div>
                </div>
             
                <br />
                <button class="btn btn-success" name="register" type="submit">Update</button>
            
            </form>
			
        <br />
        <br />
        <br />
        <br />
        </div>		
		
		
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>