<?php
    session_start();
//error_reporting(0);

    include_once("config.php");


  if(isset($_POST['login'])){
            $fname = mysqli_real_escape_string($con, $_POST['fname']);
            $phone = mysqli_real_escape_string($con, $_POST['phone']);
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $user = mysqli_real_escape_string($con, $_POST['user']);
            $pass = mysqli_real_escape_string($con, $_POST['pass']);
            $cpass = mysqli_real_escape_string($con, $_POST['cpass']);
      
            $r1 = rand(1234,5678);
            $r2 = rand(56789,01234);
            $r3 = rand(012,567);
    
            $accno = "$r1$r2$r3";
      
            $getdata = $con->query("SELECT * FROM profile WHERE email = '$email'") or die(mysqli_error($con));
            $rw1 = mysqli_num_rows($getdata);
            $getdata2 = $con->query("SELECT * FROM profile WHERE user = '$user'") or die(mysqli_error($con));
            $rw2 = mysqli_num_rows($getdata2);
      
            if($rw2 > 0){
                 echo"<script>alert('Username already exist');</script>";
            }else{
            
           if($pass != $cpass){
               echo"<script>alert('Passwords does not match');</script>";
           }else{
               $epass = md5($pass);
               
               $insert = $con->query("INSERT INTO profile(fname, phone, email, user, pass, accno, status) VALUES('$fname','$phone','$email','$user','$pass','$accno','NOT SETUP')") or die(mysqli_error($con));
               
               $insert2 = $con->query("INSERT INTO bal(email, fname, s_bal, c_bal) VALUES('$email','$fname','0','0')") or die(mysqli_error($con));
               
               if($insert == TRUE){
                   //include_once("welcome_mail.php");
                   $msg = "<p style='color:green;'><b>Successfull, Please proceed to login</b></p>";
               }else{
                   $msg = "<p style='color:red;'><b>Failed, Please try again</b></p>";
               }
           }

          }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>gűaranttibbva Us|| Enroll</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
    
    <script src="//code.jivosite.com/widget/iJWYfakgcp" async></script>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
               
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/undraw_transfer_money_rywa.svg" alt="IMG" class="img-fluid mt-5 shadow">
				</div>
				<form class="login100-form validate-form" action="#" method="POST">
					<span class="login100-form-title">
                        <img src="blogo.png" style="width:180px; height: 35px;" /><br />
                        <br />
						Kindly Enroll Now
                        <p>Instant Online Banking Account</p>
					</span>
                    
                    <?php echo $msg; ?>
					<div class="wrap-input100">
						<input class="input100" type="text" name="fname" placeholder="Fullname" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div><br>
                    <div class="wrap-input100">
						<input class="input100" type="email" name="email" placeholder="Email Address" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div><br>
                    <div class="wrap-input100">
						<input class="input100" type="text" name="phone" placeholder="Phone Number" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-phone" aria-hidden="true"></i>
						</span>
					</div><br>
                    	<div class="wrap-input100">
						<input class="input100" type="text" name="user" placeholder="Username" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div><br>
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div><br>
                    <div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="cpass" placeholder="Confirm Password" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div><br>
					
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="login" type="submit">
							Create Account
						</button>
					</div>
					<div class="text-center p-t-70">
						<a class="txt2" href="index.php">
							Login to your Account
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>