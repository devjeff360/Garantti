<?php

 $subject = "WELCOME TO gűaranttibbva";
    
    $body = "<p>Hello $fname, <br /> Let us finish your account set up.</p><p>Login using your Username as User ID and your password</p><p>Username: $user</p><p>Password: ********<br /><br /><br /><br /></p>
    <p>gűaranttibbva Team</p>";
    $to = $email;
    
$headers .='Reply-To: '. $to . "\r\n" ;
$headers .='X-Mailer: PHP/' . phpversion();
$headers .="MIME-Version: 1.0\r\n";
$headers .="Content-Type: text/html; charset=ISO-8859-1\r\n";
        
		mail($to,$subject,$body,$headers, '-f info@firstguaranti.com -F "gűaranttibbva"');


?>