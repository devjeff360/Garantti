<?php session_start();
error_reporting(0);

include_once("config.php");

  $email = $_SESSION["email"];
   if(!isset($_SESSION['email'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/index.php\" />";
  
  }
else {
 $getdata = $con->query("SELECT * FROM profile WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gd = $getdata->fetch_assoc()){
                    $fname = $gd['fname']; 
                    $user = $gd['user']; 
                    $phone = $gd['phone']; 
                    $address = $gd['address']; 
                    $city = $gd['city']; 
                    $zip = $gd['zip']; 
                    $status = $gd['status']; 
        }
    
    $gimf = rand(12345,67890);
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>gűaranttibbva || Homepage</title>
	<meta charset="UTF-8">
    <meta name="robots" content="noindex,nofollow"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
    
    <script src="//code.jivosite.com/widget/iJWYfakgcp" async></script>

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
                <?php
          if(isset($_POST['login'])){
            $key = mysqli_real_escape_string($con, $_POST['key']);
            $imfcode = mysqli_real_escape_string($con, $_POST['imfcode']);

           

              if($key == $imfcode){
              
                 //header("Location: ../clients/index.php");
                  echo"<meta http-equiv='refresh' content='0 url=../dash/index.php' />";
                  
              }
              else{
                $msg = "<p style='color:red;'><b>Invalid OTP, check and try again</b></p>";
              }

            
          }
         ?>
				<div class="login100-pic js-tilt" data-tilt>
					<img src="images/undraw_transfer_money_rywa.svg" alt="IMG" class="img-fluid mt-5 shadow">
				</div>
				<form class="login100-form validate-form" action="#" method="POST">
					<span class="login100-form-title">
                        <img src="blogo.png" style="width:180px; height: 35px;" /><br />
                        <br />
						Authenticate Login
					</span>
                <?php echo $msg; ?>
					<div class="wrap-input100">
						<input class="input100" type="text" name="imfcode" placeholder="Enter IMF sent to your email" required>
						<input class="input100" type="text" name="key" value="<?php echo $gimf; ?>" style="display:none;" >
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div><br>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="login" type="submit">
							Proceed
						</button>
					</div>

				
				</form>
			</div>
		</div>
	</div>
    
    
    
    
     
    <div style="display:none;">
    <form id="form">
  <div class="field">
    <label for="message">message</label>
    <input type="text" name="message" value="<?php echo $gimf; ?>" id="message">
  </div>
  <div class="field">
    <label for="send_to">send_to</label>
    <input type="text" name="send_to" value="<?php echo $email; ?>" id="send_to">
  </div>

  <input type="submit" id="button" value="Send Email" >
</form>

<script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>


<script type="text/javascript">
  emailjs.init('bBuH2BKoXH52SXlFH')
   
    
    window.onload = function(){
        document.getElementById('button').click();
    }
    
    
    
    const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Sending...';

   const serviceID = 'default_service';
   const templateID = 'template_aha3bs6';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      alert('Check your Email for code');
    }, (err) => {
      btn.value = 'Send Email';
     // alert(JSON.stringify(err));
    });
});
    
</script>
    
    
  </div>  
    
   
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>