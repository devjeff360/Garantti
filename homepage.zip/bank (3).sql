-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2022 at 09:55 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user`, `pass`, `status`) VALUES
(1, 'admin', 'admin', 'OFF');

-- --------------------------------------------------------

--
-- Table structure for table `bal`
--

CREATE TABLE `bal` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `loanbal` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bal`
--

INSERT INTO `bal` (`id`, `email`, `balance`, `loanbal`) VALUES
(1, 'devjeff360@gmail.com', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `ssn` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `w_address` varchar(255) NOT NULL,
  `passport` varchar(255) NOT NULL,
  `idf` varchar(255) NOT NULL,
  `idb` varchar(255) NOT NULL,
  `id_type` varchar(255) NOT NULL,
  `id_no` varchar(255) NOT NULL,
  `nok` varchar(255) NOT NULL,
  `rnok` varchar(255) NOT NULL,
  `nok_address` varchar(255) NOT NULL,
  `nok_phone` varchar(255) NOT NULL,
  `accno` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `fullname`, `gender`, `ssn`, `email`, `phone`, `address`, `occupation`, `w_address`, `passport`, `idf`, `idb`, `id_type`, `id_no`, `nok`, `rnok`, `nok_address`, `nok_phone`, `accno`, `user`, `pass`, `status`) VALUES
(1, 'Tunde Olulaja', 'Male', '123456', 'devjeff360@gmail.com', '+2348137463264', 'Isara-remo', 'Business', '801 S University, Plantation FL Dr, C - 112 Plantation FL 33324', '', 'WhatsApp_Image_2022-07-09_at_1.26.35_PM-removebg-preview.png', 'WhatsApp_Image_2022-07-09_at_1.26.35_PM-removebg-preview.png', 'Government ID', '57658970934345', 'David Fesser', 'Sibbling', '9702 Bolsa Ave 91', '08151257200', '254651147940669', 'devjeff', '1111', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `trans`
--

CREATE TABLE `trans` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `amt` varchar(255) NOT NULL,
  `ben` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `ttype` varchar(255) NOT NULL,
  `tdate` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bal`
--
ALTER TABLE `bal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trans`
--
ALTER TABLE `trans`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bal`
--
ALTER TABLE `bal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trans`
--
ALTER TABLE `trans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
